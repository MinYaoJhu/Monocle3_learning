#' 40,000 Cells from the Human Cell Atlas ICA Bone Marrow Dataset
#'
#' @format A \code{Seurat} object with 40,000 cells fromt he HCA ICA bone marrow dataset
#'
#' @source \url{https://preview.data.humancellatlas.org/}
#'
#'
#' @examples
#' \dontrun{
#' if (requireNamespace(Seurat, quietly = TRUE)) {
#'   url <- 'https://s3.amazonaws.com/preview-ica-expression-data/ica_bone_marrow_h5.h5'
#'   curl::curl_download(url = url, destfile = basename(path = url))
#'   hcabm.data <- Seurat::Read10X_h5(filename = basename(path = url))
#'   hcabm <- Seurat::CreateSeuratObject(counts = hcabm.data, project = 'hcabm40k', min.cells = 100, min.features = 500)
#'   set.seed(seed = 42)
#'   hcabm40k <- subset(x = hcabm, downsample = 5000)
#'   file.remove(basename(path = url))
#' }
#' }
#'
"hcabm40k"